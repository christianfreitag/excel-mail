##EXmail

Email service for sending emails to multiple recipients with different customizable messages from a list from excel. You be able to choose between using gmail, hotmail or a customizable service of email.

Before use you need to configure the service and configuration about rows and columns from excel you want to use. 

To use a custom message htmol template you need to add the tag '<#!=J=!#>' where the message should be rendered, The 'J' indicates the column of the excel file where message, name, any kind of information is stored.